List of the shared files:
1. schematics of the iAQ demonstrator - file: AirCareDemo_Cube.pdf
2. schematics of the noise sensor     - file: Noise_sensor_envelope_v03.pdf
3. source files of PC application (Visual Studio project) - file: iAQmeter_TCPclient.rar
4. source code of firmware running on Arduino  - file: AirCare_prototype_v03.ino
5. source code of sensor libraries included in firmware - file: libraries.rar
6. sensor interfaces description  -file: Sensor_interfaces_v01.docx
7. sensor datasheets - file: Sensors_datasheet.rar